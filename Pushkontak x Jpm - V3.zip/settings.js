/* 
   © HAPUS CREDIT? UMUR MINUS 5THUN
   
   Developer Script : Fyxzpedia
   Contact Devv : t.me/Fyxzpedia
   Saluran Testimoni: https://whatsapp.com/channel/0029Vb6O4Wd6GcGEWNvexE0v
   Link Profil: https://rb.gy/x4eox9
   
   Hargai Pembuat Script Free
   
*/
const chalk = require("chalk");
const fs = require("fs");

global.owner = "6283193211556"
global.namaOwner = "Fyxzpedia"

global.dana = "0"
global.ovo = "Tidak tersedia"
global.gopay = "Tidak tersedia"
global.qris = "https://files.catbox.moe/q4u6w2.jpg"

global.JedaPushkontak = 3500 // 1000 = 1detik
global.JedaJpm = 5000  // 1000 = 1detik
global.mess = {
owner: "Fitur ini hanya untuk ownerbot.", 
group: "Fitur ini hanya dapat digunakan ketika bot berada di dalam grup.", 
private: "Fitur ini hanya dapat digunakan ketika bot berada di private chat.", 
admin: "Fitur ini hanya dapat digunakan admin grup.", 
botadmin: "Fitur ini hanya dapat digunakan ketika bot menjadi admin grup.", 
}

let file = require.resolve(__filename) 
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.blue(">> Update File :"), chalk.black.bgWhite(`${__filename}`))
delete require.cache[file]
require(file)
})