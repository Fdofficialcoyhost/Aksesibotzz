/* 
   © HAPUS CREDIT? UMUR MINUS 5THUN
   
   Developer Script : Fyxzpedia
   Contact Devv : t.me/Fyxzpedia
   Saluran Testimoni: https://whatsapp.com/channel/0029Vb6O4Wd6GcGEWNvexE0v
   Link Profil: https://rb.gy/x4eox9
   
   Hargai Pembuat Script Free
   
*/