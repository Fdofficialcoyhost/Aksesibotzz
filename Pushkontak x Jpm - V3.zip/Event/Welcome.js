require("../settings.js");
const fs = require("fs");

async function WelcomeMessage(sock, update, groupMetadataCache) {
  try {
  let botSettings = JSON.parse(fs.readFileSync("./Data/setbot.json"));
  const { id, author, participants, action } = update;
  let groupMetadata;

  try {
    groupMetadata = await sock.groupMetadata(id);
    groupMetadataCache.set(id, groupMetadata);
  } catch (error) {
    console.error(`Gagal mengambil atau memperbarui metadata grup untuk ${id}:`, error);
    groupMetadata = groupMetadataCache.get(id);
    if (!groupMetadata) {
      console.error(`Metadata grup tidak tersedia bahkan di cache untuk ${id}. Menghentikan proses.`);
      return;
    }
  }

  if (!botSettings.welcome) {
    return;
  }

  const groupSubject = groupMetadata.subject;
  const commonMessageSuffix = `\n\n📢 Jangan lupa join grup :\n\n${global.linkGrup}`;

  for (const participant of participants) {
    let messageText = "";
    const authorName = author ? author.split("@")[0] : "";
    const participantName = participant.split("@")[0];

    switch (action) {
      case "add":
        messageText =
          author === participant
            ? `@${authorName} Telah *menambahkan* @${participantName} ke dalam grup.`
            : `@${participantName} Selamat datang di grup ${groupSubject}`;
        break;
      case "remove":
        messageText =
          author !== participant
            ? `@${participantName} Telah *keluar* dari grup.`
            : `@${authorName} Telah *mengeluarkan* @${participantName} dari grup.`;
        break;
      case "promote":
        messageText = `@${authorName} Telah *menjadikan* @${participantName} sebagai *admin* grup.`;
        break;
      case "demote":
        messageText = `@${authorName} Telah *menghentikan* @${participantName} sebagai *admin* grup.`;
        break;
      default:
        continue;
    }

    messageText += commonMessageSuffix;

    try {
      await sock.sendMessage(id, {
        text: messageText,
        mentions: [author, participant],
      }, { quoted: null });
    } catch (error) {
    }
  }
  } catch (err) {
  console.log(err)
  }
}

module.exports = WelcomeMessage;
