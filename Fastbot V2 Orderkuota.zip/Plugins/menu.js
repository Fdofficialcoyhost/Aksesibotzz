const handler = async (m, { sock, isOwner }) => {
const teks = `
📩𝐅𝐚𝐬𝐭𝐛𝐨𝐭 𝐌𝐞𝐬𝐬𝐞𝐧𝐠𝐞𝐫 𝐅𝐨𝐫 𝐘𝐨𝐮.. 
🇮🇸 : I am Fastbot made from Source code created by Fyxzpedia to Assist Whatsapp Activities
🇲🇨 : Saya adalah Fastbot yang dibuat dari Source code yang dibuat oleh Fyxzpedia untuk Membantu Aktivitas Whatsapp

*𝐇𝐚𝐢 @${m.sender.split("@")[0]} 🔒*
- Botmode: ${sock.public ? "Public" : "Self"}
- Runtime: ${runtime(process.uptime())}
- Creator: @${global.owner}

▬▭▬▭▬▭▬▭▬▭▬▭
➤『 𝐌𝐀𝐈𝐍 𝐌𝐄𝐍𝐔 』
▬▭▬▭▬▭▬▭▬▭▬▭
> .rvo  
> .getpp  
> .script  
> .brat  
> .toghibli  
> .tohitam  
> .sticker  
> .swm  

▬▭▬▭▬▭▬▭▬▭▬▭
➤『 𝐒𝐇𝐎𝐎𝐏 𝐌𝐄𝐍𝐔 』
▬▭▬▭▬▭▬▭▬▭▬▭
> .belipanel  
> .belireseller  
> .beliadp  
> .beliscript  
> .topupdana  
> .topupgopay  
> .topupovo  
> .topupml  
> .topupff  

▬▭▬▭▬▭▬▭▬▭▬▭
➤『 𝐓𝐎𝐎𝐋𝐒 𝐌𝐄𝐍𝐔 』
▬▭▬▭▬▭▬▭▬▭▬▭
> .trackip
> .trackweb
> .ai  
> .ssweb  
> .ocr  
> .tourl  
> .tourl2  
> .pinterest  
> .readqr  
> .enchard  
> .enchard2  
> .tohd  
> .removebg  

▬▭▬▭▬▭▬▭▬▭▬▭
➤『 𝐃𝐎𝐖𝐍𝐋𝐎𝐀𝐃 𝐌𝐄𝐍𝐔 』
▬▭▬▭▬▭▬▭▬▭▬▭
> .tiktok  
> .facebook  
> .instagram  
> .mediafire  
> .gitclone  
> .play  
> .ytmp3  
> .ytmp4  
> .xnxx  

▬▭▬▭▬▭▬▭▬▭▬▭
➤『 𝐒𝐄𝐀𝐑𝐂𝐇 𝐌𝐄𝐍𝐔 』
▬▭▬▭▬▭▬▭▬▭▬▭
> .yts  
> .npm  
> .nsfw  
> .xnxxs  

▬▭▬▭▬▭▬▭▬▭▬▭
➤『 𝐒𝐓𝐎𝐑𝐄 𝐌𝐄𝐍𝐔 』
▬▭▬▭▬▭▬▭▬▭▬▭
> .jpm  
> .jpmht  
> .puskontak  
> .setjeda  
> .savekontak  
> .startjpm  
> .setjpm  
> .delsetjpm  
> .listgc  
> .testi  
> .payment  
> .proses  
> .done  

▬▭▬▭▬▭▬▭▬▭▬▭
➤『 𝐆𝐑𝐎𝐔𝐏 𝐌𝐄𝐍𝐔 』
▬▭▬▭▬▭▬▭▬▭▬▭
> .kudeta  
> .antilink  
> .antilink2  
> .antilinkch  
> .bljpm  
> .delbljpm  
> .open / .close  
> .kick  
> .hidetag  
> .promote  
> .demote  
> .acc / .reject  

▬▭▬▭▬▭▬▭▬▭▬▭
➤『 𝐂𝐇𝐀𝐍𝐍𝐄𝐋 𝐌𝐄𝐍𝐔 』
▬▭▬▭▬▭▬▭▬▭▬▭
> .addidch  
> .listidch  
> .delidch  
> .jpmch  
> .idch  
> .joinch  
> .reactch  

▬▭▬▭▬▭▬▭▬▭▬▭
➤『 𝐏𝐀𝐍𝐄𝐋 𝐌𝐄𝐍𝐔 』
▬▭▬▭▬▭▬▭▬▭▬▭
> .1gb - .10gb  
> .unlimited  
> .listpanel  
> .delpanel  
> .cadmin  
> .listadmin  
> .deladmin  
> .addakses  
> .listakses  
> .delakses  
> .subdomain  
> .installpanel  
> .uninstallpanel  
> .startwings  
> .hbpanel  

▬▭▬▭▬▭▬▭▬▭▬▭
➤『 𝐃𝐈𝐆𝐈𝐓𝐀𝐋𝐎𝐂𝐄𝐀𝐍 𝐌𝐄𝐍𝐔 』
▬▭▬▭▬▭▬▭▬▭▬▭
> .createvps  
> .listdroplet  
> .deldroplet  
> .rebuildvps  

▬▭▬▭▬▭▬▭▬▭▬▭
➤『 𝐒𝐄𝐓𝐁𝐎𝐓 𝐌𝐄𝐍𝐔 』
▬▭▬▭▬▭▬▭▬▭▬▭
> .autopromosi
> .autoread  
> .autotyping  
> .autojoingc  
> .anticall  
> .setppbot  
> .welcome  

▬▭▬▭▬▭▬▭▬▭▬▭
➤『 𝐎𝐖𝐍𝐄𝐑 𝐌𝐄𝐍𝐔 』
▬▭▬▭▬▭▬▭▬▭▬▭
> .addplugin  
> .saveplugin  
> .listplugin  
> .delplugin  
> .addown  
> .delown  
> .listown  
> .addsc  
> .delsc  
> .getsc  
> .addrespon  
> .listrespon  
> .delrespon  
> .getcase  
> .addcase  
> .listcase  
> .block  
> .backupsc  
> .clearsesion  
> .clearchat  
> .restart
`
await sock.sendMessage(m.chat, {text: teks, contextInfo: {
mentionedJid: [m.sender, global.owner + "@s.whatsapp.net"], 
isForwarded: true, 
forwardedNewsletterMessageInfo: {
newsletterJid: global.idChannel,
newsletterName: `Powered by ${global.namaOwner}`, 
serverId: 200
}, 
externalAdReply: {
title: `© 𝐒𝐢𝐦𝐩𝐥𝐞𝐛𝐨𝐭 𝐅𝐚𝐬𝐭𝐛𝐨𝐭 𝐕𝟐.𝟎.𝟎✅`,
body: `𝘈𝘶𝘵𝘰𝘳𝘪𝘻𝘦𝘥 𝘉𝘰𝘵 𝘞𝘩𝘢𝘵𝘴𝘈𝘱𝘱 2025`, 
thumbnailUrl: global.thumbnail, 
renderLargerThumbnail: true, 
mediaType: 1, 
previewType: 1, 
sourceUrl: "", 
}}
}, {quoted: null })
}

handler.command = ["menu"]
module.exports = handler