const handler = async (m, { sock }) => {
let teks = `
𝐅𝐚𝐬𝐭𝐛𝐨𝐭 𝐕𝟐 𝐒𝐨𝐮𝐫𝐜𝐞 𝐂𝐨𝐝𝐞

- Source Code No Enc 100%
- Full Button & Support WA Business
- Security (ON)
- Support Costum Pairing Code
- Type Case X Plugin
- Size Ringan (Fast Respon)
- Price ? Rp25.000

Contact Admin: t.me/Fyxznewcuy
`
return sock.relayMessage(m.chat,  {requestPaymentMessage: {currencyCodeIso4217: 'IDR', amount1000: 25000000, requestFrom: m.sender, noteMessage: { extendedTextMessage: { text: teks }}}}, {})
}

handler.command = ["sc", "script"]
module.exports = handler