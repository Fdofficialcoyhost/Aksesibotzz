

const chalk = require("chalk");
const fs = require("fs");


//============ Setting Bot ============//

global.owner = "6283126046404"
global.namaOwner = "Fyxzpedia"
global.namaBot = "Fastbot"
global.versiBot = "2.0.0"
global.idChannel = "120363421024821152@newsletter"
global.namaChannel = "~ Fyxz testimoni"
global.linkChannel = "https://whatsapp.com/channel/0029Vb6S58V1noz1Vq0qq40B"
global.linkGrup = "Exp"
global.thumbnail = "https://img1.pixhost.to/images/7490/625981052_rizzhosting.jpg"


//========== Setting Payment ===========//

global.payment = {
dana: "085198699020", 
ovo: "-", 
gopay: "-", 
qris: "https://img1.pixhost.to/images/7490/625981136_rizzhosting.jpg"
}


//========== Setting Api Panel ===========//

global.egg = "15" // Isi id egg
global.nestid = "5" // Isi id nest
global.loc = "1" // Isi id location
global.domain = "https://bot.ricotasya.my.id"
global.apikey = "ptlc_ANumWL0UsjKoe9jtw1r911mmPBQftjVa2GCUhSZdSZm" // Isi api ptla
global.capikey = "ptla_3I4C7v89Issh2kJrPFP0LW9QFtQJ5iEWvS9oAGPSomi" // Isi api ptlc


global.linkGrupResellerPanel = ""


//========= Setting Api Digitalocean =======//

global.apiDigitalOcean = ""


//========== Setting Api RestApi =========//

global.ApikeyRestApi = "free"


//========= Setting Api Orderkuota =========//

global.QrisOrderKuota = "00020101021126670016COM.NOBUBANK.WWW01189360050300000879140214502450929274860303UMI51440014ID.CO.QRIS.WWW0215ID20253689540410303UMI5204541153033605802ID5923FYXZ OFFICIAL OK21315656008PASURUAN61056711162070703A016304C9A4"

global.ApikeyOrderKuota = "84685421728928182208243OKCTF5EC133AC4A0C62E4E29B23C43291972"

global.usernameOrderkuota = "fadilmerchant"

global.tokenOrderkuota = "2088243:gGrny3pwsEWxudlfLaNZziQMPhj7Ke"

global.IdMerchant = "OK2131565"

global.pinH2H = "1231"

global.passwordH2H = "1231"


//========= Setting Api Subdomain ========//

global.subdomain = {
  "pteroweb.my.id": {
    "zone": "714e0f2e54a90875426f8a6819f782d0",
    "apitoken": "vOn3NN5HJPut8laSwCjzY-gBO0cxeEdgSLH9WBEH"
  },
  "panelwebsite.biz.id": {
    "zone": "2d6aab40136299392d66eed44a7b1122",
    "apitoken": "CcavVSmQ6ZcGSrTnOos-oXnawq4yf86TUhmQW29S"
  },
  "privatserver.my.id": {
    "zone": "699bb9eb65046a886399c91daacb1968",
    "apitoken": "CcavVSmQ6ZcGSrTnOos-oXnawq4yf86TUhmQW29S"
  },
  "serverku.biz.id": {
    "zone": "4e4feaba70b41ed78295d2dcc090dd3a",
    "apitoken": "CcavVSmQ6ZcGSrTnOos-oXnawq4yf86TUhmQW29S"
  },
  "vipserver.web.id": {
    "zone": "e305b750127749c9b80f41a9cf4a3a53",
    "apitoken": "cpny6vwi620Tfq4vTF4KGjeJIXdUCax3dZArCqnT"
  }, 
  "mypanelstore.web.id": {
    "zone": "c61c442d70392500611499c5af816532",
    "apitoken": "uaw-48Yb5tPqhh5HdhNQSJ6dPA3cauPL_qKkC-Oa"
  }
}


//=========== Setting Message ===========//

global.mess = {
owner: "Fitur ini hanya untuk ownerbot.", 
group: "Fitur ini hanya dapat digunakan ketika bot berada di dalam grup.", 
private: "Fitur ini hanya dapat digunakan ketika bot berada di private chat.", 
admin: "Fitur ini hanya dapat digunakan admin grup.", 
botadmin: "Fitur ini hanya dapat digunakan ketika bot menjadi admin grup.", 
}



let file = require.resolve(__filename);
fs.watchFile(file, () => {
    fs.unwatchFile(file);
    console.log(chalk.green(`File update: ${__filename}`));
    delete require.cache[file];
    require(file);
});