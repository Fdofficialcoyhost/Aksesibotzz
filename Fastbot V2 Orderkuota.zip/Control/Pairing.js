const PairCode = "BBBBBBBB"

module.exports = PairCode